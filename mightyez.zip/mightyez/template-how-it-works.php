<?php
/*
Template Name: How it Works
*/

get_header(); ?>

<!-- Hero Banner -->
<?php get_template_part( 'parts/content', 'hero-banner' ); ?>

<!-- How it Works Intro -->
<?php get_template_part( 'parts/content', 'how-it-works-intro' ); ?>

<!-- How it Works Illustration -->
<?php get_template_part( 'parts/content', 'how-it-works-illustration' ); ?>

<!-- Tips -->
<?php get_template_part( 'parts/content', 'tips' ); ?>

<!-- Before and After -->
<?php get_template_part( 'parts/content', 'before-after' ); ?>

<!-- Disclaimer -->
<?php get_template_part( 'parts/content', 'disclaimer' ); ?>

<?php get_footer(); ?>
