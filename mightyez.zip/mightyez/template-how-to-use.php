<?php
/*
Template Name: How to Use
*/

get_header(); ?>
			
<!-- Hero Banner -->
<?php get_template_part( 'parts/content', 'hero-banner' ); ?>

<!-- Directions -->
<?php get_template_part( 'parts/content', 'directions' ); ?>

<!-- Tips -->
<?php get_template_part( 'parts/content', 'tips' ); ?>

<!-- Warnings -->
<?php get_template_part( 'parts/content', 'warnings' ); ?>

<!-- Disclaimer -->
<?php get_template_part( 'parts/content', 'disclaimer-gray' ); ?>

<?php get_footer(); ?>
