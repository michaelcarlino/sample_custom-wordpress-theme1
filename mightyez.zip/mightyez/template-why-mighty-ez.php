<?php
/*
Template Name: Why Mighty EZ
*/

get_header(); ?>

<!-- Hero Banner -->
<?php get_template_part( 'parts/content', 'hero-banner' ); ?>

<!-- Why Intro -->
<?php get_template_part( 'parts/content', 'why-intro' ); ?>
			
<!-- Product Features -->
<?php get_template_part( 'parts/loop', 'product-features' ); ?>

<!-- Product Uses Inside -->
<?php get_template_part( 'parts/loop', 'product-uses-inside' ); ?>

<!-- Product Uses -->
<?php get_template_part( 'parts/loop', 'product-uses' ); ?>

<!-- Disclaimer -->
<?php get_template_part( 'parts/content', 'disclaimer-gray' ); ?>	

<?php get_footer(); ?>
