

<!-- Tips (repeater) -->

<?php
$tips_title = get_field('tips_title');
$tips_image = get_field('tips_image');
$tips_disclaimer_text = get_field('tips_disclaimer_text');
?>



<div style="background-color: #1a1d1f;">	
<div class="grid-container ptb75">
  <div class="grid-x grid-margin-x">
    <div class="cell large-6"><h3 class="tips-title"><?php echo $tips_title; ?></h3><?php if( have_rows('tips') ): ?>
 
    <ul class="bullet-lightning">
 
    <?php while( have_rows('tips') ): the_row(); ?>
 
        <li class="bullet-lightning"><p class="tips"><?php the_sub_field('tip_text'); ?></p></li>
              
    <?php endwhile; ?>
 
    </ul>
 
	<?php endif; ?>

	<!-- Tips Disclaimer -->
	<p class="tips-disclaimer"><?php echo $tips_disclaimer_text; ?></p>

	</div>

    <div class="cell large-6"><img src="<?php echo $tips_image; ?>"></div>
  </div>
</div>
</div>





