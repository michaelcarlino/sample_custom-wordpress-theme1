
<!-- Header Slider -->


<?php
$header_slide_1 = get_field('header_slide_1', 'option');
$header_slide_2 = get_field('header_slide_2', 'option'); 
$header_slide_3 = get_field('header_slide_3', 'option');
$header_slide_4 = get_field('header_slide_4', 'option');
$header_slide_5 = get_field('header_slide_5', 'option');
$header_slide_6 = get_field('header_slide_6', 'option');

$header_slide_1_mobile = get_field('header_slide_1_mobile', 'option');
$header_slide_2_mobile = get_field('header_slide_2_mobile', 'option'); 
$header_slide_3_mobile = get_field('header_slide_3_mobile', 'option');
$header_slide_4_mobile = get_field('header_slide_4_mobile', 'option');
$header_slide_5_mobile = get_field('header_slide_5_mobile', 'option');
$header_slide_6_mobile = get_field('header_slide_6_mobile', 'option');

$header_banner_headline = get_field('header_banner_headline', 'option');
$header_banner_subhead = get_field('header_banner_subhead', 'option');

$icon_strip_image = get_field('icon_strip_image', 'option');
$slider_icon_1 = get_field('slider_icon_1', 'option');
$slider_icon_2 = get_field('slider_icon_2', 'option');
$slider_icon_3 = get_field('slider_icon_3', 'option');
$slider_icon_4 = get_field('slider_icon_4', 'option');
$slider_icon_5 = get_field('slider_icon_5', 'option');
$slider_icon_6 = get_field('slider_icon_6', 'option');

$slider_icon_name_1 = get_field('slider_icon_name_1', 'option');
$slider_icon_name_2 = get_field('slider_icon_name_2', 'option');
$slider_icon_name_3 = get_field('slider_icon_name_3', 'option');
$slider_icon_name_4 = get_field('slider_icon_name_4', 'option');
$slider_icon_name_5 = get_field('slider_icon_name_5', 'option');
$slider_icon_name_6 = get_field('slider_icon_name_6', 'option');

$usage_chart_button_link = get_field('usage_chart_button_link', 'option');
?>

<!-- Mobile -->
<div class="orbit" role="region" aria-label="header slider" data-orbit data-options="animInFromLeft:fade-in; animInFromRight:fade-in; animOutToLeft:fade-out; animOutToRight:fade-out; autoPlay:true; infiniteWrap:true; pauseOnHover: false; " data-use-m-u-i="true">




<div class="grid-container">
  <div class="grid-x grid-margin-x">
    <div class="cell small-12 medium-12 large-12 hide-for-large"><div class="header-banner-headline"><?php echo $header_banner_headline; ?></div><h1 class="header-banner-subhead"><?php echo $header_banner_subhead; ?></h1></div>
    <div class="cell small-12 medium-12 large-12 hide-for-large">
      <!-- slider images mobile-->
      <ul class="orbit-container">
        <li class="orbit-slide is-active">
            <img class="orbit-image" src="<?php echo $header_slide_1_mobile; ?>" alt="">
        </li>
       <li class="orbit-slide">
            <img class="orbit-image" src="<?php echo $header_slide_2_mobile; ?>" alt="">
        </li>
        <li class="orbit-slide">
            <img class="orbit-image" src="<?php echo $header_slide_3_mobile; ?>" alt="">
        </li>
        <li class="orbit-slide">
            <img class="orbit-image" src="<?php echo $header_slide_4_mobile; ?>" alt="">
        </li>
        <li class="orbit-slide">
            <img class="orbit-image" src="<?php echo $header_slide_5_mobile; ?>" alt=""> 
        </li>
        <li class="orbit-slide">
            <img class="orbit-image" src="<?php echo $header_slide_6_mobile; ?>" alt="">
        </li>
      </ul>
    </div>
    </div>
  </div>
</div>

<!-- Mighty EZ bottle image -->
      <div class="cell large-3 hide-for-large"><img src="<?php echo $icon_strip_image; ?>" class="icon-strip-image-mobile"></div>

<!-- End Mobile -->




<div class="orbit" role="region" aria-label="header slider" data-orbit data-options="animInFromLeft:fade-in; animInFromRight:fade-in; animOutToLeft:fade-out; animOutToRight:fade-out; autoPlay:true; infiniteWrap:true; pauseOnHover: false; " data-use-m-u-i="true">

<div class="grid-container">
  <div class="grid-x custom-header-width">
    <!-- home header banner -->
    <div class="cell small-12 medium-12 large-6 show-for-large mt100"><div class="header-banner-headline"><?php echo $header_banner_headline; ?></div><h1 class="header-banner-subhead"><?php echo $header_banner_subhead; ?></h1></div>

    
    

    <!-- slider images -->
    <div class="cell large-6">
      <ul class="orbit-container show-for-large">
        <li class="orbit-slide is-active">
            <img class="orbit-image circle-mask" src="<?php echo $header_slide_1; ?>" alt="">
        </li>
       <li class="orbit-slide">
            <img class="orbit-image circle-mask" src="<?php echo $header_slide_2; ?>" alt="">
        </li>
        <li class="orbit-slide">
            <img class="orbit-image circle-mask" src="<?php echo $header_slide_3; ?>" alt="">
        </li>
        <li class="orbit-slide">
            <img class="orbit-image circle-mask" src="<?php echo $header_slide_4; ?>" alt="">
        </li>
        <li class="orbit-slide">
            <img class="orbit-image circle-mask" src="<?php echo $header_slide_5; ?>" alt=""> 
        </li>
        <li class="orbit-slide">
            <img class="orbit-image circle-mask" src="<?php echo $header_slide_6; ?>" alt="">
        </li>
      </ul>
    </div>
  </div>
</div>

   
  <!-- slider icons -->
  <div class="icon-strip-bg show-for-large"><!-- icon strip bg -->
   <div class="grid-container show-for-large">
    <div style="width:87.5rem;" class="grid-x">
      <div class="cell large-9">
        <nav class="icon-strip orbit-bullets">
          <div class="grid-container">
            <div class="grid-x">
              <div class="cell large-2"><button class="icon-strip is-active" data-slide="0"><img src="<?php echo $slider_icon_1; ?>" /></button></div>
              <div class="cell large-2"><button data-slide="1"><img src="<?php echo $slider_icon_2; ?>" /></button></div>
              <div class="cell large-2"><button data-slide="2"><img src="<?php echo $slider_icon_3; ?>" /></button></div>
              <div class="cell large-2"><button data-slide="3"><img src="<?php echo $slider_icon_4; ?>" /></button></div>
              <div class="cell large-2"><button data-slide="4"><img src="<?php echo $slider_icon_5; ?>" /></button></div>
              <div class="cell large-2"><button data-slide="5"><img src="<?php echo $slider_icon_6; ?>" /></button></div>
            </div>
          </div> 
          <div style="margin-top: 20px;" class="grid-container">
            <div class="grid-x">
              <div class="cell large-2"><h6 class="icon-strip"><?php echo $slider_icon_name_1; ?></h6></div>
              <div class="cell large-2"><h6 class="icon-strip"><?php echo $slider_icon_name_2; ?></h6></div>
              <div class="cell large-2"><h6 class="icon-strip"><?php echo $slider_icon_name_3; ?></h6></div>
              <div class="cell large-2"><h6 class="icon-strip"><?php echo $slider_icon_name_4; ?></h6></div>
              <div class="cell large-2"><h6 class="icon-strip"><?php echo $slider_icon_name_5; ?></h6></div>
              <div class="cell large-2"><h6 class="icon-strip"><?php echo $slider_icon_name_6; ?></h6></div>
            </div>
          </div> 
        </nav>
          </div>

      <!-- Mighty EZ bottle image -->
      <div class="cell large-3"><img src="<?php echo $icon_strip_image; ?>" class="icon-strip-image show-for-large"></div>

      
      <!-- Usage Chart Button (right side) -->
      <a href="<?php echo $usage_chart_button_link; ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/usage-chart-button.png" class="show-for-large" id="usage-chart-button"></a>
   
  </div>
</div>
</div>







