

<!-- How it Works Illustration -->

<?php
$how_it_works_illustration_image_1 = get_field('how_it_works_illustration_image_1');
$how_it_works_illustration_image_2 = get_field('how_it_works_illustration_image_2');
$how_it_works_illustration_image_3 = get_field('how_it_works_illustration_image_3');
$how_it_works_illustration_text_1 = get_field('how_it_works_illustration_text_1');
$how_it_works_illustration_text_2 = get_field('how_it_works_illustration_text_2');
$how_it_works_illustration_text_3 = get_field('how_it_works_illustration_text_3');
?>



<div class="grid-container mtb150">
  <div class="grid-x grid-margin-x">
    <div class="cell large-4"><img src="<?php echo $how_it_works_illustration_image_1; ?>" class="how-illustration"><p class="how-it-works-illustration"><?php echo $how_it_works_illustration_text_1; ?></p></div>
    <div class="cell large-4"><img src="<?php echo $how_it_works_illustration_image_2; ?>" class="how-illustration"><p class="how-it-works-illustration"><?php echo $how_it_works_illustration_text_2; ?></p></div>
    <div class="cell large-4"><img src="<?php echo $how_it_works_illustration_image_3; ?>" class="how-illustration"><p class="how-it-works-illustration"><?php echo $how_it_works_illustration_text_3; ?></p></div>
  </div>
</div>