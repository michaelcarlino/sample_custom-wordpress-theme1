

<!-- How it Works Intro -->

<?php
$how_it_works_intro_headline = get_field('how_it_works_intro_headline');
$how_it_works_intro_subhead = get_field('how_it_works_intro_subhead'); 
$how_it_works_intro_text = get_field('how_it_works_intro_text');
?>



<div class="grid-container mtb150">
  <div class="grid-x grid-margin-x">
    <div class="cell large-6"><h3 class="intro-headline"><?php echo $how_it_works_intro_headline; ?></h4></div>
    <div class="cell large-6"><h5 class="intro-subhead"><?php echo $how_it_works_intro_subhead; ?></h4><p><?php echo $how_it_works_intro_text ?></p>
    </div>
  </div>
</div>


