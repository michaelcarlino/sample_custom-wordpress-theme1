

<!-- Where to Buy Contact -->

<?php

$business_name = get_field('business_name', 'option');
$business_address = get_field('business_address', 'option');
$business_map_url = get_field('business_map_url', 'option');

$social_media_title = get_field('social_media_title', 'option');
$facebook_icon = get_field('facebook_icon', 'option');
$facebook_url = get_field('facebook_url', 'option');
$twitter_icon = get_field('twitter_icon', 'option');
$twitter_url = get_field('twitter_url', 'option');
$instagram_icon = get_field('instagram_icon', 'option');
$instagram_url = get_field('instagram_url', 'option');

$where_to_buy_contact_text = get_field('where_to_buy_contact_text');
$where_to_buy_contact_form = get_field('where_to_buy_contact_form');
$where_to_buy_contact_us_title = get_field('where_to_buy_contact_us_title');
?>



<div style="background-color: #1a1d1f;" class="ptb150">		
<div class="grid-container">
  <div class="grid-x grid-margin-x">
  	
  	<!-- column 1 -->
    <div class="cell large-6"><h5 class="where-to-buy-contact-text"><?php echo $where_to_buy_contact_text ?></h5></div>
    
    <!-- column 2 -->
    <div class="cell large-4"><a href="<?php echo $business_map_url ?>" target="_blank"><h6 class="where-to-buy-contact-business"><?php echo $business_name ?></h6>
    <div class="where-to-buy-contact-text"><?php echo $business_address ?></div></a></div>
    
    <!-- column 3 -->
    <div class="cell large-2 social-media-icons footer-text-bold">
    	<div class="where-to-buy-contact-text-bold"><?php echo $social_media_title ?></div>
    	<a href="<?php echo $facebook_url ?>" target="_blank"><img src="<?php echo $facebook_icon ?>" height="15" width="15"> </a>
		 <a href="<?php echo $twitter_url ?>" target="_blank"><img src="<?php echo $twitter_icon ?>" height="30" width="30"> </a> <a href="<?php echo $instagram_url ?>" target="_blank"><img src="<?php echo $instagram_icon ?>" height="30" width="30"></a> 
    </div>
    
  </div>
</div>
</div>


<!-- Contact Form -->
<div class="grid-container mtb150" id="contact-us">
  <div class="grid-x grid-margin-x">
    <div class="cell large-12"><h5 class="where-to-buy-contact-us-title"><?php echo $where_to_buy_contact_us_title ?></h5>
  </div>
    <div class="cell large-12"><div><?php echo $where_to_buy_contact_form ?></div>
  </div>
</div>
</div>


		

		





