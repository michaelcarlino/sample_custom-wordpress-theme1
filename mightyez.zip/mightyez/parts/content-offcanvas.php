<?php
/**
 * The template part for displaying offcanvas content
 *
 * For more info: http://jointswp.com/docs/off-canvas-menu/
 */
?>
<?php
$facebook_icon = get_field('facebook_icon', 'option');
$facebook_url = get_field('facebook_url', 'option');
$twitter_icon = get_field('twitter_icon', 'option');
$twitter_url = get_field('twitter_url', 'option');
$instagram_icon = get_field('instagram_icon', 'option');
$instagram_url = get_field('instagram_url', 'option');
?>


<div class="off-canvas position-left" data-transition="overlap" id="off-canvas" data-off-canvas>

	<div class="grid-container mt75">
	  <div class="grid-x grid-margin-x">
		<div class="cell small-12 medium-12 large-12 offcanvas-nav"><?php joints_mainmenu_nav(); ?><?php joints_topbar_nav(); ?></div>
	    </div>
	    <div class="cell small-12 medium-12 large-12 mt25 social-media-icons-mobile footer-text-bold-mobile">
    	<a href="<?php echo $facebook_url ?>" target="_blank"><img src="<?php echo $facebook_icon ?>" height="10" width="10"> </a>
		 <a href="<?php echo $twitter_url ?>" target="_blank"><img src="<?php echo $twitter_icon ?>" height="20" width="20"> </a> <a href="<?php echo $instagram_url ?>" target="_blank"><img src="<?php echo $instagram_icon ?>" height="20" width="20"></a> 
	    </div>
	</div>
	<button class="close-button close-mobile" aria-label="Close alert" type="button" data-close>
    <span aria-hidden="true">&times;</span>
  </button>
</div>

	
	
	
	
	




	
	


