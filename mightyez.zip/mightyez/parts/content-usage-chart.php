

<!-- Usage Chart (table) -->
<?php 
$usage_chart_title = get_field('usage_chart_title');
?>

<div class="grid-container mtb150">
  <div class="grid-x ">
  	<div class="cell large-12 mb75"><h5 class="usage-chart-title"><?php echo $usage_chart_title; ?></h5></div>

    <div class="cell large-4">
		<?php
		$table = get_field( 'usage_chart_removes' );



		if ( ! empty ( $table ) ) {

		    echo '<table bordercolor="#f3f3f3" border="0">';

		        if ( ! empty( $table['caption'] ) ) {

		            echo '<caption>' . $table['caption'] . '</caption>';
		        }

		        if ( ! empty( $table['header'] ) ) {

		            echo '<thead style="background-color:#ffcd03">';

		                echo '<tr>';

		                    foreach ( $table['header'] as $th ) {

		                        echo '<th><h5 class="usage-chart-thead">';
		                            echo $th['c'];
		                        echo '</h5></th>';
		                    }

		                echo '</tr>';

		            echo '</thead>';
		        }

		        echo '<tbody>';

		            foreach ( $table['body'] as $tr ) {

		                echo '<tr>';

		                    foreach ( $tr as $td ) {

		                        echo '<td><p class="usage-chart-text">';
		                            echo $td['c'];
		                        echo '</p></td>';
		                    }

		                echo '</tr>';
		            }

		        echo '</tbody>';

		    echo '</table>';
		}
		?>
		</div>

		 <div class="cell large-4">
		<?php
		$table = get_field( 'usage_chart_applications' );



		if ( ! empty ( $table ) ) {

		    echo '<table bordercolor="#f3f3f3" border="0">';

		        if ( ! empty( $table['caption'] ) ) {

		            echo '<caption>' . $table['caption'] . '</caption>';
		        }

		        if ( ! empty( $table['header'] ) ) {

		            echo '<thead style="background-color:#ffcd03">';

		                echo '<tr>';

		                    foreach ( $table['header'] as $th ) {

		                        echo '<th><h5 class="usage-chart-thead">';
		                            echo $th['c'];
		                        echo '</h5></th>';
		                    }

		                echo '</tr>';

		            echo '</thead>';
		        }

		        echo '<tbody>';

		            foreach ( $table['body'] as $tr ) {

		                echo '<tr>';

		                    foreach ( $tr as $td ) {

		                        echo '<td><p class="usage-chart-text">';
		                            echo $td['c'];
		                        echo '</p></td>';
		                    }

		                echo '</tr>';
		            }

		        echo '</tbody>';

		    echo '</table>';
		}
		?>
		</div>

		 <div class="cell large-4">
		<?php
		$table = get_field( 'usage_chart_cleans' );



		if ( ! empty ( $table ) ) {

		    echo '<table bordercolor="#f3f3f3" border="0">';

		        if ( ! empty( $table['caption'] ) ) {

		            echo '<caption>' . $table['caption'] . '</caption>';
		        }

		        if ( ! empty( $table['header'] ) ) {

		            echo '<thead style="background-color:#ffcd03">';

		                echo '<tr>';

		                    foreach ( $table['header'] as $th ) {

		                        echo '<th><h5 class="usage-chart-thead">';
		                            echo $th['c'];
		                        echo '</h5></th>';
		                    }

		                echo '</tr>';

		            echo '</thead>';
		        }

		        echo '<tbody>';

		            foreach ( $table['body'] as $tr ) {

		                echo '<tr>';

		                    foreach ( $tr as $td ) {

		                        echo '<td><p class="usage-chart-text">';
		                            echo $td['c'];
		                        echo '</p></td>';
		                    }

		                echo '</tr>';
		            }

		        echo '</tbody>';

		    echo '</table>';
		}
		?>
		</div>
	</div>
</div>




 





 


