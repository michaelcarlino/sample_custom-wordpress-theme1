

<!-- Where to Buy Intro -->

<?php
$where_to_buy_intro_image = get_field('where_to_buy_intro_image');
$where_to_buy_intro_text = get_field('where_to_buy_intro_text');
$where_to_buy_intro_phone = get_field('where_to_buy_intro_phone');
$where_to_buy_image_url = get_field('where_to_buy_image_url');
?>


	<div class="grid-container mtb150">
	  <div class="grid-x">
	    <div class="cell large-12">
	    	<h3 class="intro-title"><?php the_title(); ?></h3>
	    	<center><a href="<?php echo $where_to_buy_image_url; ?>" target="_blank"><img src="<?php echo $where_to_buy_intro_image; ?>" class="mtb25"></a></center>
	    	<h5 class="where-to-buy-text"><?php echo $where_to_buy_intro_text; ?><span><a href="tel:<?php echo $where_to_buy_intro_phone; ?>" class="phone"><?php echo $where_to_buy_intro_phone; ?></span></a></h5>
	    </div>
	  </div>
	</div>