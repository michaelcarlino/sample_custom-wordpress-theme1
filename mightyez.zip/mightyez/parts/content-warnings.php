



<!-- Warnings (repeater) -->

	
<div class="grid-container mtb150">
  <div class="grid-x grid-margin-x">
    <div class="cell large-6"><?php if( have_rows('warnings_column_1') ): ?>
 
    <ul style="list-style: none;">
 
    <?php while( have_rows('warnings_column_1') ): the_row(); ?>
 
        <li><h5 class="warnings-title"><?php the_sub_field('column_1_warning_title'); ?></h5><p><?php the_sub_field('column_1_warning_text'); ?></p></li>
              
    <?php endwhile; ?>
 
    </ul>
 
<?php endif; ?></div>
    <div class="cell large-6"><?php if( have_rows('warnings_column_2') ): ?>
 
    <ul style="list-style: none;">
 
    <?php while( have_rows('warnings_column_2') ): the_row(); ?>
 
        <li><h5 class="warnings-title"><?php the_sub_field('column_2_warning_title'); ?></h5><p><?php the_sub_field('column_2_warning_text'); ?></p></li>
              
    <?php endwhile; ?>
 
    </ul>
 
<?php endif; ?></div>
  </div>
</div>

