<?php
/**
 * Off-Canvas MAIN MENU (custom)
 *
 * The off-canvas menu uses the Off-Canvas Component
 *
 */
?>

<div class="grid-container">
	<div class="grid-x">
		<div class="cell small-4 medium-4 large-4 show-for-large">
			<div class="pulse-box">
			<!-- Generator: Adobe Illustrator 22.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="54px" height="105px" viewBox="0 0 54 105" style="enable-background:new 0 0 54 105;" xml:space="preserve" class="pulse-svg lightning-svg">
<style type="text/css">
	.st0{fill:url(#lightning_1_);}
</style>
<linearGradient id="lightning_1_" gradientUnits="userSpaceOnUse" x1="-48.1405" y1="46.16" x2="77.9895" y2="46.16" gradientTransform="matrix(1 0 -0.1 -1 -15.89 98.66)">
	<stop  offset="0.22" style="stop-color:#FFC810"/>
	<stop  offset="0.36" style="stop-color:#FEDF00"/>
	<stop  offset="0.38" style="stop-color:#FFE300"/>
	<stop  offset="0.46" style="stop-color:#FCEE23"/>
	<stop  offset="0.59" style="stop-color:#FEE800"/>
	<stop  offset="0.68" style="stop-color:#FEDF00"/>
	<stop  offset="0.78" style="stop-color:#FED600"/>
	<stop  offset="1" style="stop-color:#FFC810"/>
</linearGradient>
<polyline id="lightning" class="st0 lightning" points="21.6,0.5 5.4,45.8 21.8,45.8 0.1,104.5 53.9,33.3 39.7,33.3 47.1,14.3 48.2,11 
	52.3,0.5 21.6,0.5 "/>
</svg>	
	    	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="header-logo" src="<?php the_field('header_logo', 'option'); ?>" alt="Mighty EZ" /></a>
			</div>
		</div>

		<div class="cell small-8 medium-8 large-8">
			<div class="show-for-large float-right main-menu-style main-menu-position"><?php joints_mainmenu_nav();?>	
			</div>
		</div>
	</div>
</div>



<!-- Mobile Main Menu -->
<div class="grid-container hide-for-large">
  <div class="grid-x">
    <div class="cell small-11 medium-11"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="header-logo-mobile" src="<?php the_field('header_logo', 'option'); ?>" alt="Mighty EZ" /></a>
    </div>
    <div class="cell small-1 medium-1">
    <button class="mobilemenu menu-icon" type="button" data-toggle="off-canvas"></button>
    </div>
 </div>
</div>



