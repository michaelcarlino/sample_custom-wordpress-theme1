<?php
/**
 * Template part for displaying page content in page.php (revised)
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(''); ?> role="article" itemscope itemtype="http://schema.org/WebPage">
						
	<header class="mb50">
		<h5 class="page"><?php the_title(); ?></h5>
	</header> <!-- end article header -->
					
    <section>
	    <?php the_content(); ?>
	</section> <!-- end article section -->
						
	<footer>
		 <?php wp_link_pages(); ?>
	</footer> <!-- end article footer -->
						    
	<?php comments_template(); ?>
					
</article> <!-- end article -->