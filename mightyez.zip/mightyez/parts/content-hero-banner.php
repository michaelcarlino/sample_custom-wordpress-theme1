

<!-- Hero Banner -->

<?php
$hero_banner = get_field('hero_banner');
$usage_chart_button_link = get_field('usage_chart_button_link', 'option');
?>


	<div class="grid-container full">
	  <div class="grid-x">
	    <div class="cell large-12 hero-image" style='display: flex; background-image:url(<?php echo $hero_banner; ?>);'>
	    </div>
	    <div class="show-for-large"><!-- Usage Chart Button (right side) -->
      <a href="<?php echo $usage_chart_button_link; ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/usage-chart-button.png" id="usage-chart-button"></a>
	  </div>
	</div>