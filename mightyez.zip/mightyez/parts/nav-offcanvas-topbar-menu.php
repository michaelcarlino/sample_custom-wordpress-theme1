


<!-- Off-Canvas TOPBAR MENU (custom) -->



<?php
$social_media_title = get_field('social_media_title', 'option');
$facebook_icon = get_field('facebook_icon', 'option');
$facebook_url = get_field('facebook_url', 'option');
$twitter_icon = get_field('twitter_icon', 'option');
$twitter_url = get_field('twitter_url', 'option');
$instagram_icon = get_field('instagram_icon', 'option');
$instagram_url = get_field('instagram_url', 'option');
?>

<section class="show-for-large nav-topbar-menu-bg">
<div class="grid-container">
	<div class="grid-x grid-margin-x">
		<div class="cell auto">
		</div>
		<div class="cell shrink">
			<div class="show-for-large float-right">
				<div class="topbar-menu-layout nav-topbar-style"><?php joints_topbar_nav();?></div>
			<!-- <a href="<?php echo $facebook_url ?>" target="_blank"><img class="social-media-icons-topbar"src="<?php echo $facebook_icon ?>" height="10" width="10"> </a>
		 <a href="<?php echo $twitter_url ?>" target="_blank"><img class="social-media-icons-topbar" src="<?php echo $twitter_icon ?>" height="20" width="20"> </a> <a href="<?php echo $instagram_url ?>" target="_blank"><img class="social-media-icons-topbar" src="<?php echo $instagram_icon ?>" height="20" width="20"></a> --> 	
			</div>
		</div>
	</div>
</div>
</section>




