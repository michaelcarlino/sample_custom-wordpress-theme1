

<!-- Before and After -->

<?php
$before_image = get_field('before_image');
$after_image = get_field('after_image');
?>



<div class="grid-container full">
  <div class="grid-x">
    <div class="cell large-6 hero-image-before-after" style='display: flex; background-image:url(<?php echo $before_image; ?>);'></div>
    <div class="cell large-6 hero-image-before-after" style='display: flex; background-image:url(<?php echo $after_image; ?>);'></div>
  </div>
</div>