

<!-- Directions -->

<?php
$directions_title = get_field('directions_title');
$directions_step_1_image = get_field('directions_step_1_image');
$directions_step_1_text = get_field('directions_step_1_text');
$directions_step_2_image = get_field('directions_step_2_image');
$directions_step_2_text = get_field('directions_step_2_text');
$directions_step_3_image = get_field('directions_step_3_image');
$directions_step_3_text = get_field('directions_step_3_text');
$directions_disclaimer = get_field('directions_disclaimer');
?>

	
<div class="grid-container mtb150">
	<div class="grid-x grid-margin-x">
    <div class="cell large-12"><h3 class="directions-title"><?php echo $directions_title; ?></h3></div>
  </div>
  <div class="grid-x grid-margin-x">
    <div class="cell large-4 text-center"><img src="<?php echo $directions_step_1_image; ?>" class="directions-icon"><h5 class="directions-text"><?php echo $directions_step_1_text; ?></h5></div>
    <div class="cell large-4 text-center"><img src="<?php echo $directions_step_2_image; ?>" class="directions-icon"><h5 class="directions-text"><?php echo $directions_step_2_text; ?></h5></div>
    <div class="cell large-4 text-center"><img src="<?php echo $directions_step_3_image; ?>" class="directions-icon"><h5 class="directions-text"><?php echo $directions_step_3_text; ?></h5></div>
  </div>
  <div class="grid-x grid-margin-x">
    <div class="cell large-12"><p class="directions-disclaimer-text"><?php echo $directions_disclaimer; ?></p></div>
  </div>
</div>

