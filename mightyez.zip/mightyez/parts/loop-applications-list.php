

<!-- Applications List (loop) -->


<!-- View Our Aplications List -->
<?php
$applications_list_text =  get_field('applications_list_text');
$applications_list_arrow = get_field('applications_list_arrow');
?>

<div id="applications-list" class="grid-container mb75">
  <div class="grid-x grid">
    <div class="cell large-12 text-center"><h5 class="applications-list"><?php echo $applications_list_text; ?></h5><img src="<?php echo $applications_list_arrow; ?>" class="applications-list-arrow"></div>
  </div>
</div>
<!-- END -->


<div class="grid-container full">
<div class="grid-x large-padding-collapse" data-equalizer>
<?php 

// the query
$the_query = new WP_Query( array( 'post_type' => 'applications_list', 'posts_per_page' => -1 ) ); ?>

<?php if ( $the_query->have_posts() ) : ?>

<!-- the loop -->
<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
 
<?php
$applications_list_image =  get_field('applications_list_image');
$applications_list_icon_white = get_field('applications_list_icon_white');
$applications_list_icon_black = get_field('applications_list_icon_black');

$applications_list_popup_text = get_field('applications_list_popup_text');

$id = uniqid(); 
?>




<!-- START loop -->
<div style="padding-bottom: .3rem; padding-left: .2rem;padding-right: .2rem;" class="small-12 medium-12 large-4 cell">
	<div data-open="<?php echo $id; ?>"><!-- start modal trigger wrap -->
		<div class="overlay-image">
			<div class="hero-image-applications-list" style='background-image:url(<?php echo $applications_list_image; ?>);'></div>
				<div class="text"><img src="<?php echo $applications_list_icon_white; ?>" height="80px" width="80px"><div class="applications-title"><?php the_title(); ?></div></div>
			 <div class="hover">
			 <div class="text"><img src="<?php echo $applications_list_icon_black; ?>" height="80px" width="80px"><div class="applications-title"><?php the_title(); ?></div>
			 </div></div>
		</div>
	</div><!-- end modal trigger wrap -->

	
	<!-- start modal (reveal) -->
	<div class="large-popup reveal" id="<?php echo $id; ?>" data-reveal data-overlay="true">
		  <div class="grid-container full">
		    <div class="grid-x grid-margin-x">
		      <div class="cell small-12 medium-12 large-8 show-for-large"><div class="hero-image-applications-list-popup" style='background-image:url(<?php echo $applications_list_image; ?>);'></div></div>
		      <div class="cell small-12 medium-12 large-4">
		      	<div class="cell large-12 reveal-spacing"><img src="<?php echo $applications_list_icon_white; ?>" height="100px" width="100px"><h4 class="applications-list-popup-title"><?php the_title(); ?></h4>
		      	</div><!-- end nested 12 -->
		      	
		      	<div class="cell large-12 reveal-spacing2">
		      		<div><?php
		$table = get_field( 'applications_list_popup_text' );

		if ( ! empty ( $table ) ) {

		    echo '<table class="unstriped applications-popup">';

		        if ( ! empty( $table['caption'] ) ) {

		            echo '<caption>' . $table['caption'] . '</caption>';
		        }

		        if ( ! empty( $table['header'] ) ) {

		            echo '<thead>';

		                echo '<tr>';

		                    foreach ( $table['header'] as $th ) {

		                        echo '<th>';
		                            echo $th['c'];
		                        echo '</th>';
		                    }

		                echo '</tr>';

		            echo '</thead>';
		        }

		        echo '<tbody>';

		            foreach ( $table['body'] as $tr ) {

		                echo '<tr>';

		                    foreach ( $tr as $td ) {

		                        echo '<td><p class="applications-list-popup">';
		                            echo $td['c'];
		                        echo '</p></td>';
		                    }

		                echo '</tr>';
		            }

		        echo '</tbody>';

		    echo '</table>';
		}
		?></div>
		      		
		      	</div><!-- end nested 12 -->

		      </div><!-- end grid-4 -->
		    </div>
		  </div>
		  
		  <!-- Modal close button -->
		  <button class="close-button reveal-popup" data-close aria-label="Close modal" type="button">
		    <span aria-hidden="true">&times;</span>
		  </button>
	</div>
	<!-- end modal (reveal) -->

</div><!-- END Cell -->





<?php endwhile; ?>
<!-- end of the loop -->

<!-- <?php wp_reset_postdata(); ?> -->

<?php else : ?>

<p><?php esc_html_e( 'Sorry no application found, please add a application.' ); ?></p>

<?php endif; ?>
</div>
</div>

