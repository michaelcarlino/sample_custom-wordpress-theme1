


<!-- Product Uses (loop) -->


<div class="grid-container full mb150">
<div class="grid-x" data-equalizer>
<?php 

// the query
$the_query = new WP_Query( array( 'post_type' => 'product_uses', 'posts_per_page' => -1 ) ); ?>

<?php if ( $the_query->have_posts() ) : ?>

<!-- the loop -->
<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
 
<?php
$product_uses_image =  get_field('product_uses_image');
$product_uses_icon = get_field('product_uses_icon');
$product_uses_text = get_field('product_uses_text');
?>


<!-- START loop -->
<div style="padding-left: .2rem;padding-right: .2rem;" class="small-12 medium-12 large-4 cell">
	<div class="hero-image-product-uses" style='background-image:url(<?php echo $product_uses_image; ?>);'></div>
	<img src="<?php echo $product_uses_icon; ?>" class="product-uses-icon">
	<h4 class="product-uses-title"><?php the_title(); ?></h4>
	<p class="product-uses-text"><?php echo $product_uses_text; ?></p>
</div>

<?php endwhile; ?>
<!-- end of the loop -->

<!-- <?php wp_reset_postdata(); ?> -->

<?php else : ?>

<p><?php esc_html_e( 'Sorry no product use found, please add a product use.' ); ?></p>

<?php endif; ?>
</div>
</div>