

<!-- Why Intro -->

<?php
$why_intro_text = get_field('why_intro_text');
?>


	<div class="grid-container mtb150">
	  <div class="grid-x">
	    <div class="cell large-12"><h3 class="intro-title"><?php the_title(); ?></h3><p class="why-intro"><?php echo $why_intro_text; ?></p></div>
	  </div>
	</div>



