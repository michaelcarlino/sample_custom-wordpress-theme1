

<!-- Disclaimer (white background)-->

<?php
$disclaimer_text = get_field('disclaimer_text', 'option');
?>

<div style="background-color: #ffffff;">
<div class="grid-container ptb150">
  <div class="grid-x grid-margin-x align-center">
    <div class="cell large-12 disclaimer-text"><?php echo $disclaimer_text; ?></div>
  </div>
</div>
</div>