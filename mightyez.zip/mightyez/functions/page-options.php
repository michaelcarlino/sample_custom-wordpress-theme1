<?php
// Theme Settings (Options Page)
if( function_exists('acf_add_options_page') ) {
	
	acf_add_options_page(array(
		'page_title' 	=> 'Theme Settings',
		'menu_title'	=> 'Theme Settings',
		'menu_slug' 	=> 'theme-settings',
		'capability'	=> 'edit_posts',
		'redirect'		=> true
		
	));

	acf_add_options_sub_page(array(
		'page_title' 	=> 'Business Info',
		'menu_title'	=> 'Business Info',
		'parent_slug'	=> 'theme-settings',
	));

	acf_add_options_sub_page(array(
		'page_title' 	=> 'Logo',
		'menu_title'	=> 'Logo',
		'parent_slug'	=> 'theme-settings',
	));

	acf_add_options_sub_page(array(
		'page_title' 	=> 'Header Slider',
		'menu_title'	=> 'Header Slider',
		'parent_slug'	=> 'theme-settings',
	));

	acf_add_options_sub_page(array(
		'page_title' 	=> 'Usage Chart Button',
		'menu_title'	=> 'Usage Chart Button',
		'parent_slug'	=> 'theme-settings',
	));

	acf_add_options_sub_page(array(
		'page_title' 	=> 'Social Media',
		'menu_title'	=> 'Social Media',
		'parent_slug'	=> 'theme-settings',
	));

	acf_add_options_sub_page(array(
		'page_title' 	=> 'Made in USA Logo',
		'menu_title'	=> 'Made in USA Logo',
		'parent_slug'	=> 'theme-settings',
	));
	
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Disclaimer',
		'menu_title'	=> 'Disclaimer',
		'parent_slug'	=> 'theme-settings',
	));
	
}





















