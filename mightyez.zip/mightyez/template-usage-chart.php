<?php
/*
Template Name: Usage Chart
*/

get_header(); ?>
			
<!-- Hero Banner -->
<?php get_template_part( 'parts/content', 'hero-banner' ); ?>

<!-- Usage Chart -->
<?php get_template_part( 'parts/content', 'usage-chart' ); ?>

<!-- Disclaimer -->
<?php get_template_part( 'parts/content', 'disclaimer-gray' ); ?>

<?php get_footer(); ?>