<?php
/*
Template Name: Home
*/

get_header(); ?>

<!-- Slider -->
<?php get_template_part( 'parts/header', 'slider' ); ?>

<!-- Home Intro -->
<?php get_template_part( 'parts/content', 'home-intro' ); ?>

<!-- Applications List -->
<?php get_template_part( 'parts/loop', 'applications-list' ); ?>

<!-- Product Features -->
<?php get_template_part( 'parts/loop', 'product-features' ); ?>

<!-- Disclaimer -->
<?php get_template_part( 'parts/content', 'disclaimer' ); ?>

<?php get_footer(); ?>