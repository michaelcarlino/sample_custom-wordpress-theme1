

<!-- Footer -->

<?php
$footer_logo = get_field('footer_logo', 'option');

$business_name = get_field('business_name', 'option');
$business_address = get_field('business_address', 'option');
$business_map_url = get_field('business_map_url', 'option');

$social_media_title = get_field('social_media_title', 'option');
$facebook_icon = get_field('facebook_icon', 'option');
$facebook_url = get_field('facebook_url', 'option');
$twitter_icon = get_field('twitter_icon', 'option');
$twitter_url = get_field('twitter_url', 'option');
$instagram_icon = get_field('instagram_icon', 'option');
$instagram_url = get_field('instagram_url', 'option');

$made_in_usa_logo = get_field('made_in_usa_logo', 'option');
?>


<div style="background-color: #1a1d1f;" class="footer-spacing">		
<div class="grid-container">
  <div class="grid-x grid-margin-x">
  	
  	<!-- column 1 -->
    <div class="cell large-2 footer-col-1"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="footer-logo-size" src="<?php echo $footer_logo; ?>" alt="MightyEZ" /></a></div>
    
    <!-- column 2 -->
    <div class="cell small-12 medium-12 large-2 footer-col-2 footer-nav show-for-large"><?php joints_footer_links(); ?></div>
    
    <!-- column 3 -->
    <div class="cell large-4 footer-col-3"><a href="<?php echo $business_map_url ?>" target="_blank"><div class="footer-text-bold"><?php echo $business_name ?></div>
    <div class="footer-text"><?php echo $business_address ?></div></a></div>
    
    <!-- column 4 -->
    <!-- <div class="cell large-3 footer-colo-4 social-media-icons footer-text-bold">
    	<div class=""><?php echo $social_media_title ?></div>
    	<a href="<?php echo $facebook_url ?>" target="_blank"><img src="<?php echo $facebook_icon ?>" height="10" width="10"> </a>
		 <a href="<?php echo $twitter_url ?>" target="_blank"><img src="<?php echo $twitter_icon ?>" height="20" width="20"> </a> <a href="<?php echo $instagram_url ?>" target="_blank"><img src="<?php echo $instagram_icon ?>" height="20" width="20"></a> 
    </div> -->
    
    <!-- column 5 -->
    <div class="cell large-3 footer-col-5"><img class="footer-logo-size" src="<?php echo $made_in_usa_logo; ?>" alt="MightyEZ Made in the USA" /></div>
  </div>
</div>
<!-- Back to Top -->
<a href="#0" class="cd-top">Top</a>

<div class="grid-container">
  <div class="grid-x">
    <div class="cell large-12"><hr class="footer-line"></div>
  </div>
  <div class="grid-x footer-copyrights-text">
    <div class="cell small-12 medium-12 large-3 copyrights">&copy; <?php echo date('Y'); ?>&nbsp;Mighty EZ.&nbsp;All rights reserved</div>
    <div class="cell small-12 medium-12 large-5"></div>
    <div class="cell small-12 medium-12 large-4 nav-privacy-style"><?php joints_privacy_policy_nav(); ?></div>
    
  </div>
</div>
</div>


 

</div>  <!-- end .off-canvas-content -->
					
		</div> <!-- end .off-canvas-wrapper -->
		
		<?php wp_footer(); ?>
		
	</body>
	
</html> <!-- end page -->




