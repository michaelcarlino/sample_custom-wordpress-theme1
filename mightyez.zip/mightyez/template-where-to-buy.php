<?php
/*
Template Name: Where to Buy
*/

get_header(); ?>
			
<!-- Hero Banner -->
<?php get_template_part( 'parts/content', 'hero-banner' ); ?>

<!-- Where to Buy Intro -->
<?php get_template_part( 'parts/content', 'where-to-buy-intro' ); ?>

<!-- Where to Buy Contact -->
<?php get_template_part( 'parts/content', 'where-to-buy-contact' ); ?>

<?php get_footer(); ?>
